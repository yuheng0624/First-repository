package com.bus.mapper;

import com.bus.entity.Title;
import com.bus.my.mapper.myMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TitleMapper extends myMapper<Title> {
}