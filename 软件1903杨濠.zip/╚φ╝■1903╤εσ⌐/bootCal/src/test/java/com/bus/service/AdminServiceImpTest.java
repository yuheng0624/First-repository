package com.bus.service;


import com.bus.entity.Admin;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AdminServiceImpTest {

    @Test
    void one(){
        Admin admin = new Admin();



    }

}